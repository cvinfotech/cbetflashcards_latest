<h1>Hi admin</h1>
<br>
<strong>Name: </strong> {{ $name }} <br>
<strong>Email: </strong> {{ $email }}<br>
<strong>Phone: </strong> {{ $phone }}<br>
<strong>Message: </strong> {{ $message1 }}<br>